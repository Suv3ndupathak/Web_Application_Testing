package Assignment3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class MakeMyTrip extends MMTBaseClass
{
	@Test(priority=1, dataProvider="testdata")
	public void SearchFlight(String from, String to) throws InterruptedException
	{
		try
		{	
			System.out.println("Handling the popup......");
			dr.findElement(By.xpath("//div[@data-cy='outsideModal']")).click();
			//Check whether the round trip button is there or not
			WebElement RoundTrip=dr.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[1]/ul/li[2]/span"));
			System.out.println("Round Trip Button Clicked.......");
			RoundTrip.click();
		}
		catch(Throwable e)
		{
			System.out.println("ElementNotFound: " + e.getMessage());
		}
		try
		{
			//Selecting Fromity
			WebDriverWait wait = new WebDriverWait(dr, 30);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='From']")));
			WebElement From=dr.findElement(By.xpath("//span[text()='From']"));
			System.out.println("FromCity button Clicked.......");
			From.click();
			WebElement City=dr.findElement(By.xpath("//input[@placeholder='From']"));
			System.out.println("Selecting from city  .......");
			City.sendKeys(from);
			WebDriverWait wait1 = new WebDriverWait(dr, 30);
			wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[text()='Kolkata, India']")));
			WebElement select=dr.findElement(By.xpath("//p[text()='Kolkata, India']"));
			System.out.println("City is Selected ..........");
			select.click();
		}
		catch(Throwable e)
		{
			System.out.println("ElementNotFound: " + e.getMessage());
		}
		try
		{
			//Selecting ToCity
			WebElement To=dr.findElement(By.xpath("//input[@placeholder='To']"));
			System.out.println("Selecting to City.......");
			To.sendKeys(to);
			WebDriverWait wait = new WebDriverWait(dr, 30);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Chennai, India']")));
			WebElement select=dr.findElement(By.xpath("//p[text()='Chennai, India']"));
			System.out.println("City is Selected ..........");
			select.click();
		}
		catch(Throwable e)
		{
			System.out.println("ElementNotFound: " + e.getMessage());
		}
		try
		{
			//Selecting Departure date from August month
			WebDriverWait wait = new WebDriverWait(dr, 30);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[2]/div[3]/div[2]/div[2]")));
			WebElement FirstDate=dr.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[2]/div[3]/div[2]/div[2]"));
			FirstDate.click();
			System.out.println("Selecting first date......");
			WebElement LastDate=dr.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[2]/div[3]/div[3]/div[7]"));
			LastDate.click();
			System.out.println("Selecting last date......");
		}
		catch(Throwable e)
		{
			System.out.println("ElementNotFound: " + e.getMessage());
		}
	}
	@Test(priority=2)
	public void Travellers()
	{
		try
		{
			//Check response after choosing  greater than 9 people as travellers
			WebDriverWait wait = new WebDriverWait(dr, 30);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Travellers & CLASS']")));
			WebElement Travellers=dr.findElement(By.xpath("//span[text()='Travellers & CLASS']"));
			Travellers.click();
			WebDriverWait wait1 = new WebDriverWait(dr, 30);
			wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[text()='4']")));
			WebElement Adult=dr.findElement(By.xpath("//li[text()='4']"));
			Adult.click();
			WebDriverWait wait2 = new WebDriverWait(dr, 30);
			wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[5]/div[1]/div/div/div[1]/ul/li[7]")));
			WebElement Child=dr.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[5]/div[1]/div/div/div[1]/ul/li[7]"));
			Child.click();
			WebElement ErrMsg=dr.findElement(By.id("smallErrorMessage"));
			String text=ErrMsg.getText();
			if(text.equals("Upto 9 passengers allowed"))
			{
				System.out.println("More than 9 passenger is selected......");
			}
			else
			{
				System.out.println("Less than 9 passenger is selected......");

			}
			WebDriverWait wait3 = new WebDriverWait(dr, 30);
			wait3.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[5]/div[1]/div/div/div[2]/ul/li[7]")));
			WebElement Infant=dr.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[5]/div[1]/div/div/div[2]/ul/li[7]"));
			Infant.click();
			WebElement ErrMsg1=dr.findElement(By.xpath("//p[text()='Number of infants cannot be more than adults']"));
			String text1=ErrMsg1.getText();
			if(text1.equals("Number of infants cannot be more than adults"))
			{
				System.out.println("More infant is selected than adults ......");
			}
			else
			{
				System.out.println("Less infant is selected than adults ......");

			}
			WebDriverWait wait4 = new WebDriverWait(dr, 30);
			wait4.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[5]/div[1]/div/div/div[2]/ul/li[1]")));
			dr.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[5]/div[1]/div/div/div[2]/ul/li[1]")).click();
			WebDriverWait wait5 = new WebDriverWait(dr, 30);
			wait5.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[5]/div[1]/div/div/div[1]/ul/li[5]")));
			dr.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[5]/div[1]/div/div/div[1]/ul/li[5]")).click();
			WebElement Apply=dr.findElement(By.xpath("//button[text()='APPLY']"));
			Apply.click();

		}
		catch(Throwable e)
		{
			System.out.println("ElementNotFound: " + e.getMessage());

		}
	}
	@Test(priority=3)
	public void Flight() throws InterruptedException
	{
		try
		{
			//Searching The Flight
			WebElement search=dr.findElement(By.xpath("//a[text()='Search']"));
			System.out.println("Searching the flights........");
			search.click();
		}
		catch(Throwable e)
		{
			System.out.println("ElementNotFound: " + e.getMessage());
		}
	}
	@Test(priority=4)
	public void BookFlight() throws InterruptedException
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(dr, 30);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("sorter_btn_onward")));
			WebElement SortFlight=dr.findElement(By.id("sorter_btn_onward"));
			System.out.println("Sorting the flight......");
			SortFlight.click();
			WebDriverWait wait1 = new WebDriverWait(dr, 30);
			wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"left-side--wrapper\"]/div/div/div[1]/div[1]/div/div[2]/ul/li[1]/a/p")));
			WebElement SortByPrice=dr.findElement(By.xpath("//*[@id=\"left-side--wrapper\"]/div/div/div[1]/div[1]/div/div[2]/ul/li[1]/a/p"));
			System.out.println("Sorting By Price..........");
			SortByPrice.click();
			WebDriverWait wait2= new WebDriverWait(dr, 30);
			wait2.until(ExpectedConditions.elementToBeClickable(By.id("sorter_btn_return")));
			WebElement SortFlightReturn=dr.findElement(By.id("sorter_btn_return"));
			System.out.println("Sorting the return flight......");
			SortFlightReturn.click();
			WebDriverWait wait3 = new WebDriverWait(dr, 30);
			wait3.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"left-side--wrapper\"]/div/div/div[1]/div[2]/div/div[2]/ul/li[1]/a/p")));	
			WebElement SortByPrice1=dr.findElement(By.xpath("//*[@id=\"left-side--wrapper\"]/div/div/div[1]/div[2]/div/div[2]/ul/li[1]/a/p"));
			System.out.println("Sorting By Price..........");
			SortByPrice1.click();
			WebDriverWait wait4 = new WebDriverWait(dr, 30);
			wait4.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"rt-domrt-jrny\"]/div/div[1]/label/div[1]/span[1]")));	
			WebElement Cheapest=dr.findElement(By.xpath("//*[@id=\"rt-domrt-jrny\"]/div/div[1]/label/div[1]/span[1]"));
			System.out.println("Choosing the cheapest flight........");
			Cheapest.click();
			WebDriverWait wait5 = new WebDriverWait(dr, 30);
			wait5.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Book Now']")));	
			//Clicking on BookNow buttton
			WebElement BookNow=dr.findElement(By.xpath("//button[text()='Book Now']"));
			System.out.println("Booking the flight.....");
			BookNow.click();
		}
		catch(Throwable e)
		{
			System.out.println("ElementNotFound: " + e.getMessage());
		}
	}
	@Test(priority=5)
	public void Rewiew()
	{
		try
		{
			//Review selection in the next page 
			WebElement Msg=dr.findElement(By.xpath("//p[text()='Kolkata to Chennai']"));
			String txt=Msg.getText();
			WebElement Msg1=dr.findElement(By.xpath("//p[text()='Chennai to Kolkata']"));
			String txt1=Msg1.getText();
			if(txt.equals("Kolkata to Chennai")&& txt1.contentEquals("Chennai to Kolkata"))
			{
				System.out.println("Review done..............");
			}
			else
			{
				System.out.println("Review not done..............");
			}
		}
		catch(Throwable e)
		{
			System.out.println("ElementNotFound: " + e.getMessage());

		}
	}
	@DataProvider(name="testdata")
	public Object[][] TestDataFeed()
	{
		Object [][] data=new Object[1][2];

		data[0][0]="Kolkata";
		data[0][1]="Chennai";

		return data;
	}
}
