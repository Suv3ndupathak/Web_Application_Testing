package Assignment2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BaseClass 
{
	public WebDriver dr;
	@BeforeClass
	public void SetUpConfiguration() throws IOException
	{
		Reporter.log("=====Browser session has started=====",true);
		File src=new File("./src/test/resources/Configuration/config.property");
		FileInputStream fs=new FileInputStream(src);	
		Properties pro=new Properties();
		pro.load(fs);
		String ChromePath=pro.getProperty("ChromeDriver");
		System.out.println("Chrome path is" +ChromePath);
//		String FirePath=pro.getProperty("FirefoxDriver");
//		System.out.println("Firefox path is" +FirePath);
		String url=pro.getProperty("URL1");
		System.setProperty("webdriver.chrome.driver", ChromePath);		
		dr=new ChromeDriver();		
		dr.manage().deleteAllCookies();
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		dr.get(url);
		Reporter.log("=====Application started=====",true);
	}
	@AfterClass
	public void ExitBrowser()
	{
		dr.quit();
		Reporter.log("=====Browser session has ended=====",true);
	}
}
