package Assignment2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
public class OlayForgotPasswd extends BaseClass
{
	public String PageLanguage;
	@Test
	public void PageName()
	{
		System.out.println("Checking page language......");
		PageLanguage=dr.findElement(By.xpath("//*[@id=\"desk-country-selector\"]/div/a")).getText();
	}	
	@Test
	public void AcceptingCookie()
	{
		try 
		{
			System.out.println("Accepting cookie policy......");
			WebDriverWait wait = new WebDriverWait(dr, 30);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("onetrust-accept-btn-handler")));
			WebElement cookie = dr.findElement(By.id("onetrust-accept-btn-handler"));
			System.out.println("Cookie button exists......");
			cookie.click();

		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}		
	}

	@Test
	public void RejectingAd()
	{
		try 
		{
			if(PageLanguage.equals("United - English"))
			{
				System.out.println("Rejecting advertisements......");
				WebElement Ad = dr.findElement(By.xpath("//*[@id=\"skinAdvisor-banner\"]/span[1]/img"));
				System.out.println("AD button exists......");
				Ad.click();
			}
			else
			{
				System.out.println("Advertisement is not there......");
			}
		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}
	}
	@Test(dataProvider="testdata")
	public void forgotPasswd(String username) throws InterruptedException 
	{
		try
		{
			//CASE- 6. Click on Forgot Password 

			System.out.println("Clicking on login button......");
			WebElement login = dr.findElement(By.className("event_profile_login"));
			System.out.println("Login button exist.....");
			login.click();
			System.out.println("Clicking on forgot password link......");
			WebElement forgotPassword=dr.findElement(By.id("phdesktopbody_0_forgotpassword"));
			System.out.println("Forgot passsword link exist.....");
			forgotPassword.click();

			System.out.println("Entering username......");
			WebElement PassResetEmail=dr.findElement(By.id("phdesktopbody_0_username"));
			System.out.println("username field exist.....");
			PassResetEmail.sendKeys(username);
			if(PageLanguage.equals("United - English"))
			{
				WebElement NextButton=dr.findElement(By.id("phdesktopbody_0_NEXT"));
				NextButton.click();
				WebElement Message=dr.findElement(By.id("phdesktopbody_0_afterSubmit"));
				String text = Message.getText();
				if(text.equals("We have sent an email to your email address, please click on the link in the email to reset your password.\n" + 
						"Didn't receive the e-mail? Return to the Reset Password page to try again."))
				{
					System.out.println("Test Passed......");
				}
				else
				{
					System.out.println("Test failed......");
				}
			}
			else if(PageLanguage.equals("Deutschland - Deutsch"))
			{
				WebElement NextButton=dr.findElement(By.id("phdesktopbody_0_WEITER"));
				NextButton.click();
				WebElement Message=dr.findElement(By.id("phdesktopbody_0_afterSubmit"));
				String text = Message.getText();
				if(text.equals("Danke dir!\n" + 
						"Sie erhalten in Kürze eine E-Mail mit einem Link zum Zurücksetzen Ihres Passworts.\n" + 
						"E-Mail nicht erhalten? Kehren Sie zur Seite Passwort zurücksetzen zurück, um es erneut zu versuchen."))
				{
					System.out.println("Test Passed......");
				}
				else
				{
					System.out.println("Test failed......");
				}
			}
			else if(PageLanguage.equals("España - Español"))
			{
				WebElement NextButton=dr.findElement(By.id("phdesktopbody_0_SIGUIENTE"));
				NextButton.click();
				WebDriverWait wait = new WebDriverWait(dr, 45);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id("phdesktopbody_0_afterSubmit")));
				WebElement Message=dr.findElement(By.id("phdesktopbody_0_afterSubmit"));
				String text = Message.getText();
				System.out.println(text);
				if(text.equals("¡GRACIAS!\n" + 
						"Recibirá un correo electrónico muy pronto con un enlace para restablecer su contraseña.\n" + 
						"¿No recibió el correo electrónico? Vuelva a la página Restablecer contraseña para volver a intentarlo."))
				{
					System.out.println("Test Passed......");
				}
				else
				{
					System.out.println("Test failed......");
				}
			}
		}
		catch(Throwable e)
		{
			System.out.println("PasswdButtonNotfound: "+e.getMessage());
		}
	}
	@DataProvider(name="testdata")
	public Object[][] TestDataFeed()
	{
		Object [][] data=new Object[1][1];

		data[0][0]="su991@gmail.com";
		return data;
	}
}
