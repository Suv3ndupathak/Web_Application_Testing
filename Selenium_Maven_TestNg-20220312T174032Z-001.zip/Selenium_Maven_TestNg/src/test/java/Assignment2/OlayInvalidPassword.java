package Assignment2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class OlayInvalidPassword extends BaseClass 
{
	public String PageLanguage;
	@Test
	public void PageName()
	{
		System.out.println("Checking page language......");
		PageLanguage=dr.findElement(By.xpath("//*[@id=\"desk-country-selector\"]/div/a")).getText();
	}	
	@Test
	public void AcceptingCookie()
	{
		try 
		{
			System.out.println("Accepting cookie policy......");
			WebDriverWait wait = new WebDriverWait(dr, 30);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("onetrust-accept-btn-handler")));
			WebElement cookie = dr.findElement(By.id("onetrust-accept-btn-handler"));
			cookie.click();
			System.out.println("Cookie button exists......");
		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}		
	}

	@Test
	public void RejectingAd()
	{
		try 
		{
			if(PageLanguage.equals("United - English"))
			{
				System.out.println("Rejecting advertisements......");
				WebElement Ad = dr.findElement(By.xpath("//*[@id=\"skinAdvisor-banner\"]/span[1]/img"));
				System.out.println("AD button exists......");
				Ad.click();
			}
			else
			{
				System.out.println("Advertisement is not there......");
			}
		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}
	}

	@Test(dataProvider="testdata")
	public void invalidPasswd(String wrgUsername, String wrgPasswd)
	{
		//CASE- 4. Email or Password are entered wrong
		try
		{
			System.out.println("Clicking on login button......");
			WebElement login = dr.findElement(By.className("event_profile_login"));
			System.out.println("Login button exist.....");
			login.click();
			
			WebElement WrongUserName = dr.findElement(By.id("phdesktopbody_0_username"));
			System.out.println("Username field exist......");
			WrongUserName.sendKeys(wrgUsername);
			WebElement WrongPasswd=dr.findElement(By.id("phdesktopbody_0_password"));
			System.out.println("Password field exist......");
			WrongPasswd.sendKeys(wrgPasswd);
			if(PageLanguage.equals("United - English"))
			{
				WebElement submit=dr.findElement(By.id("phdesktopbody_0_SIGN IN"));
				System.out.println("Clicking on submit button......");
				submit.click();
				WebElement ErrMsg = dr.findElement(By.id("phdesktopbody_0_Message"));
				String text = ErrMsg.getText();
				if(text.equals("The email and password combination you entered is incorrect. Please try again, or click the link below to create an account."))
				{
					System.out.println("Test Passed......");
				}
				else
				{
					System.out.println("Test failed......");
				}
				
			}
			else if(PageLanguage.equals("Deutschland - Deutsch"))
			{
				WebElement submit=dr.findElement(By.id("phdesktopbody_0_ANMELDEN"));
				System.out.println("Clicking on submit button......");
				submit.click();
				WebElement ErrMsg = dr.findElement(By.id("phdesktopbody_0_Message"));
				String text = ErrMsg.getText();
				if(text.equals("Die eingegebene Kombination aus Passwort und E-Mail-Adresse ist ungültig. Bitte versuchen Sie es erneut oder klicken Sie auf den Link unten, um ein neues Konto zu erstellen."))
				{
					System.out.println("Test passed......");
				}
				else
				{
					System.out.println("Test failed......");
				}
			}
			else if(PageLanguage.equals("España - Español"))
			{
				System.out.println("Accepting cookie for second time......");
				WebElement cookie = dr.findElement(By.id("onetrust-accept-btn-handler"));
				cookie.click();
				WebDriverWait wait = new WebDriverWait(dr, 30);
				wait.until(ExpectedConditions.elementToBeClickable(By.id("phdesktopbody_0_INICIAR SESIÓN")));
				WebElement submit=dr.findElement(By.id("phdesktopbody_0_INICIAR SESIÓN"));
				System.out.println("Clicking on submit button......");
				submit.click();
				WebElement ErrMsg = dr.findElement(By.id("phdesktopbody_0_Message"));
				String text = ErrMsg.getText();
				if(text.equals("La combinación de correo electrónico y la contraseña que has introducido es incorrecta. Por favor, inténtalo de nuevo, o haz clic en el siguiente enlace para crear una cuenta."))
				{
					System.out.println("Test Passed......");
				}
				else
				{
					System.out.println("Test failed......");
				}
			}

		}
		catch(Throwable e)
		{
			System.out.println("Exception is=" +e.getMessage());
		}
	}
	@DataProvider(name="testdata")
	public Object[][] TestDataFeed()
	{
		Object [][] data=new Object[1][2];

		data[0][0]="su991@gmail.com";
		data[0][1]="Test199#@";
		return data;
	}
}
