package Assignment2;

import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class OlayLogin extends BaseClass
{
	public String PageLanguage;
	@Test
	public void PageName()
	{
		System.out.println("Checking page language......");
		PageLanguage=dr.findElement(By.xpath("//*[@id=\"desk-country-selector\"]/div/a")).getText();
	}	
	@Test
	public void AcceptingCookie()
	{
		try 
		{
			System.out.println("Accepting cookie policy......");
			WebDriverWait wait = new WebDriverWait(dr, 30);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("onetrust-accept-btn-handler")));
			WebElement cookie = dr.findElement(By.id("onetrust-accept-btn-handler"));
			System.out.println("Cookie button exists......");
			cookie.click();

		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}		
	}

	@Test
	public void RejectingAd()
	{
		try 
		{
			if(PageLanguage.equals("United - English"))
			{
				System.out.println("Rejecting advertisements......");
				WebElement Ad = dr.findElement(By.xpath("//*[@id=\"skinAdvisor-banner\"]/span[1]/img"));
				System.out.println("AD button exists......");
				Ad.click();
			}
			else
			{
				System.out.println("Advertisement is not there......");
			}
		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}
	}
	@Test(priority=1)
	public void Invalidlogin()
	{
		// CASE- 1. Both Email and Password Fields are blank.
		try 
		{
			System.out.println("Clicking on login button......");
			WebElement login = dr.findElement(By.className("event_profile_login"));
			System.out.println("Login button exist.....");
			login.click();

			if(PageLanguage.equals("United - English"))
			{
				WebElement SignIn=dr.findElement(By.id("phdesktopbody_0_SIGN IN"));
				SignIn.click();
				WebElement UserNameErrMsg = dr.findElement(By.id("phdesktopbody_0_usernameerrmsg"));
				String text = UserNameErrMsg.getText();
				WebElement PassswdErrMsg = dr.findElement(By.id("phdesktopbody_0_usernameerrmsg"));
				String text1 = PassswdErrMsg.getText();
				if(text.equals("This is a mandatory field.")&& text1.equals("This is a mandatory field."))
				{
					System.out.println("UserName and Passsword fields are blank -----");
				}
				else
				{
					System.out.println("UserName and Passsword fields are not blank -----");
				}
			}
			else if(PageLanguage.equals("Deutschland - Deutsch"))
			{
				WebElement SignIn=dr.findElement(By.id("phdesktopbody_0_ANMELDEN"));
				SignIn.click();
				WebElement UserNameErrMsg = dr.findElement(By.id("phdesktopbody_0_usernameerrmsg"));
				String text = UserNameErrMsg.getText();
				WebElement PassswdErrMsg = dr.findElement(By.id("phdesktopbody_0_usernameerrmsg"));
				String text1 = PassswdErrMsg.getText();
				if(text.equals("Dieses Feld ist erforderlich.")&& text1.equals("Dieses Feld ist erforderlich."))
				{
					System.out.println("UserName and Passsword fields are blank -----");
				}
				else
				{
					System.out.println("UserName and Passsword fields are not blank -----");
				}
			}
			else if(PageLanguage.equals("España - Español"))
			{
				WebElement SignIn = dr.findElement(By.id("phdesktopbody_0_INICIAR SESIÓN"));
				SignIn.click();
				WebElement UserNameErrMsg = dr.findElement(By.id("phdesktopbody_0_usernameerrmsg"));
				String text = UserNameErrMsg.getText();
				WebElement PassswdErrMsg = dr.findElement(By.id("phdesktopbody_0_usernameerrmsg"));
				String text1 = PassswdErrMsg.getText();
				if(text.equals("Este es un campo obligatorio.")&& text1.equals("Este es un campo obligatorio."))
				{
					System.out.println("UserName and Passsword fields are blank -----");
				}
				else
				{
					System.out.println("UserName and Passsword fields are not blank -----");
				}
			}		
		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}
	}

	@Test(priority=2, dataProvider="loginData")
	public void ValidLogin(String data)
	{
		try {
			//CASE- 5. Both User name and Password are entered correctly.
			String user[] = data.split(",");
			WebElement Email = dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_username"));
			System.out.println("Username field exists -----");
			Email.sendKeys(user[0]);
			WebElement password = dr.findElement(By.id("phdesktopbody_0_password"));
			System.out.println("Password field exits -----");
			password.sendKeys(user[1]);
			if (PageLanguage.equals("United - English")) {
				WebElement submit = dr.findElement(By.id("phdesktopbody_0_SIGN IN"));
				System.out.println("Sign In Button exists -----");
				submit.click();
				//Check if login was proper or not
				WebElement SuccessfulMsg = dr.findElement(By.id("phdesktopbody_0_StepOneMessage"));
				String text = SuccessfulMsg.getText();
				if (text.equals("YOUR BASIC INFORMATION")) {
					System.out.println("Login Sucessful -----");
				} else {
					System.out.println("Login Failed -----");
				}
				//Asserting and clicking on the Signout button.
				WebElement SignOff = dr.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_LogOffLink"));
				System.out.println("Signout button exists -----");
				SignOff.click();
				WebElement LogOutonfirmation = dr
						.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_anchrContinue"));
				System.out.println("Signout Confirmation button exists -----");
				LogOutonfirmation.click();
				WebElement SignOff1 = dr.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_LogOffLink"));
				System.out.println("Signout button exists -----");
				SignOff1.click();
				WebElement LogOutonfirmation1 = dr
						.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_anchrContinue"));
				System.out.println("Signout Confirmation button exists -----");
				LogOutonfirmation1.click();
			} else if (PageLanguage.equals("Deutschland - Deutsch")) {
				WebElement submit = dr.findElement(By.id("phdesktopbody_0_ANMELDEN"));
				System.out.println("Sign In Button exists -----");
				submit.click();

				WebElement confirm = dr.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_LogOffLink"));
				System.out.println("Log Off button exists -----");
				confirm.click();
				WebElement wb5 = dr.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_anchrContinue"));
				System.out.println("Log Off confirm button exists -----");
				wb5.click();
				WebElement logoff1 = dr.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_LogOffLink"));
				System.out.println("Log Off button exists -----");
				logoff1.click();
				WebElement confirm1 = dr.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_anchrContinue"));
				System.out.println("Log Off confirm button exists -----");
				confirm1.click();
			} else if (PageLanguage.equals("España - Español")) {
				System.out.println("Handling the cookie again......");
				WebElement cookie = dr.findElement(By.id("onetrust-accept-btn-handler"));
				System.out.println("Cookie button exists......");
				cookie.click();

				WebElement submit = dr.findElement(By.id("phdesktopbody_0_INICIAR SESIÓN"));
				System.out.println("Sign In Button exists -----");
				submit.click();
				WebElement logoff = dr.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_LogOffLink"));
				System.out.println("Log Off button exists -----");
				logoff.click();
				WebElement confirm = dr.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_anchrContinue"));
				System.out.println("Log Off confirm button exists -----");
				confirm.click();
				WebElement logoff1 = dr.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_LogOffLink"));
				System.out.println("Log Off button exists -----");
				logoff1.click();
				WebElement confirm1 = dr.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_anchrContinue"));
				System.out.println("Log Off confirm button exists -----");
				confirm1.click();
			} 
		} catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}
	}
	@DataProvider(name="loginData")
	public String[] readJson() throws IOException, ParseException
	{
		JSONParser jsp=new JSONParser();
		FileReader file=new FileReader("./src/test/resources/JsonFile/login.json");
		Object obj=jsp.parse(file);
		JSONObject jsonObj=(JSONObject) obj;
		JSONArray userLoginArray=(JSONArray) jsonObj.get("userlogins"); 
		String arr[]=new String[userLoginArray.size()];
		for(int i=0; i<userLoginArray.size();i++)
		{
			JSONObject users=(JSONObject) userLoginArray.get(i);
			String user=(String) users.get("username");
			String pwd=(String) users.get("password");
			arr[i]=user+ "," +pwd;
		}
		return arr;
		
	}
}
