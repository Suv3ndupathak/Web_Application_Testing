package Assignment2;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import jxl.read.biff.BiffException;

public class OLayRegistration extends BaseClass
{
	public String PageLanguage;
	@Test
	public void PageName()
	{
		System.out.println("Checking page language......");
		PageLanguage=dr.findElement(By.xpath("//*[@id=\"desk-country-selector\"]/div/a")).getText();
	}	
	@Test
	public void AcceptingCookie()
	{
		try 
		{
			System.out.println("Accepting cookie policy......");
			WebDriverWait wait = new WebDriverWait(dr, 30);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("onetrust-accept-btn-handler")));
			WebElement cookie = dr.findElement(By.id("onetrust-accept-btn-handler"));
			System.out.println("Cookie button exists......");
			cookie.click();
		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}		
	}

	@Test
	public void RejectingAd()
	{
		try 
		{
			if(PageLanguage.equals("United - English"))
			{
				System.out.println("Rejecting advertisements......");
				WebElement Ad = dr.findElement(By.xpath("//*[@id=\"skinAdvisor-banner\"]/span[1]/img"));
				System.out.println("AD button exists......");
				Ad.click();
			}
			else
			{
				System.out.println("Advertisement is not there......");
			}
		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}
	}

	@Test(priority=1)
	public void InvalidRegistration()
	{
		//CASE- 1. Details are not inserted
		try 
		{
			System.out.println("Clicking on registration button......");
			WebElement reg=dr.findElement(By.className("event_profile_register"));
			System.out.println("Registration button exists......");
			reg.click();
		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}
		try 
		{
			System.out.println("Clicking on submit button......");
			WebElement submit=dr.findElement(By.id("phdesktopbody_0_submit"));
			System.out.println("Submit button exists......");
			submit.click();
		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}
		try 
		{
			System.out.println("Checking the error message......");
			WebElement ErrMsg = dr.findElement(By.id("phdesktopbody_0_ErrorMessage"));
			System.out.println("Error message exists......");
			String text = ErrMsg.getText();
			if(PageLanguage.equals("United - English"))
			{
				if(text.equals("Fields marked with * are mandatory. Please complete all mandatory fields and re-submit."))
				{
					System.out.println("Test Passed......");
				}
				else
				{
					System.out.println("Test Failed......");
				}
			}
			else if(PageLanguage.equals("Deutschland - Deutsch"))
			{
				if(text.equals("Felder mit einem * sind Pflichtfelder. Bitte füllen Sie alle Pflichtfelder aus."))
				{
					System.out.println("Registration Detail fields are blank -----");
				}
				else
				{
					System.out.println("Registration detail fields are not blank -----");
				}
			}
			else if(PageLanguage.equals("España - Español"))
			{
				if(text.equals("Los campos marcados con * son obligatorios. Completa todos los campos obligatorios y vuelve a enviar."))
				{
					System.out.println("Registration Detail fields are blank -----");
				}
				else
				{
					System.out.println("Registration detail fields are not blank -----");
				}
			}
		} 
		catch (Exception e) 
		{
			System.out.println("Exception is=" +e.getMessage());
		}
	}

	@Test(priority=2,dataProvider="testData")
	public void ValidRegistration2(String username,String password, String confirmpasswd, String firstname, 
			String lastname, String country, String address, String city, String postal, 
			String day, String month, String year ) throws BiffException, IOException
	{	

		if(PageLanguage.equals("United - English"))
		{
			try 
			{
				//Entering Email
				WebElement Email=dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_grs_account[emails][0][address]"));
				System.out.println("Email field exists -----");
				Email.sendKeys(username);
				//Entering Password
				WebElement Password=dr.findElement(By.id("phdesktopbody_0_grs_account[password][password]"));
				System.out.println("Password field exists -----");
				Password.sendKeys(password);

				//Entering Confirm Password
				WebElement Confirmpasswd=dr.findElement(By.id("phdesktopbody_0_grs_account[password][confirm]"));
				System.out.println("Confirm password field exists -----");
				Confirmpasswd.sendKeys(confirmpasswd);

				//Selecting Date
				Select date= new Select(dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][day]")));
				System.out.println("Date DropDown exists -----");
				date.selectByValue(day);

				//Selecting Month
				Select Month= new Select(dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][month]")));
				System.out.println("Month DropDown exists -----");
				Month.selectByValue(month);

				//Selecting Year
				Select Year= new Select(dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][year]")));
				System.out.println("Year DropDown exists -----");
				Year.selectByValue(year);
				//Submitting the form
				WebElement submit=dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_submit"));
				System.out.println("Submit button exists -----");
				submit.click();
				WebDriverWait wait = new WebDriverWait(dr, 30);
				wait.until(ExpectedConditions.elementToBeClickable(By.name("phdesktopbody_1$phdesktopbody_0_grs_consumer[firstname]")));
				//Entering Subscription Data
				WebElement name=dr.findElement(By.name("phdesktopbody_1$phdesktopbody_0_grs_consumer[firstname]"));
				System.out.println("Firstname field exists -----");
				name.sendKeys(firstname);
				WebElement Lastname=dr.findElement(By.name("phdesktopbody_1$phdesktopbody_0_grs_consumer[lastname]"));
				System.out.println("Lastname field exists -----");
				Lastname.sendKeys(lastname);
				WebElement Address=dr.findElement(By.id("phdesktopbody_0_labelgrs_account[addresses][0][line1]"));
				System.out.println("Address field exists -----");
				Address.sendKeys(address);	
				WebElement City=dr.findElement(By.id("phdesktopbody_0_labelgrs_account[addresses][0][city]"));
				System.out.println("City field exists -----");
				City.sendKeys(city);
				WebElement Postal=dr.findElement(By.id("phdesktopbody_0_grs_account[addresses][0][postalarea]"));
				System.out.println("Postal field exists -----");
				Postal.sendKeys(postal);

				//Submit
				WebElement Save=dr.findElement(By.id("phdesktopbody_0_SubmitBtn"));
				System.out.println("Submit button exists -----");
				Save.click();
				
				String url = dr.getCurrentUrl();
				if(url.equals("https://www.olay.co.uk/en-gb/loginpage/create-profile-thank-you-page"))
				{
					System.out.println("Test Passed......");
				}
				else
				{
					System.out.println("Test Failed......");
				}
			}
			catch (Exception e) 
			{
				System.out.println("Exception is=" +e.getMessage());
			}
		}
		else if(PageLanguage.equals("Deutschland - Deutsch")) 
		{
			try 
			{
				WebElement gender = dr.findElement(By.id("phdesktopbody_0_imgmale"));
				System.out.println("Gender field exists -----");
				gender.click();

				WebElement Firstname = dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_grs_consumer[firstname]"));
				System.out.println("First name field exists -----");
				Firstname.sendKeys(firstname);

				WebElement Lastname = dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_grs_consumer[lastname]"));
				System.out.println("Last name field exists -----");
				Lastname.sendKeys(lastname);

				WebElement Email = dr.findElement(By.id("phdesktopbody_0_grs_account[emails][0][address]"));
				System.out.println("Email Address field exists -----");
				Email.sendKeys(username);

				WebElement Password = dr.findElement(By.id("phdesktopbody_0_grs_account[password][password]"));
				System.out.println("Password field exists -----");
				Password.sendKeys(password);

				WebElement Confirmpasswd = dr.findElement(By.id("phdesktopbody_0_grs_account[password][confirm]"));
				System.out.println("Confirm password field exists -----");
				Confirmpasswd.sendKeys(confirmpasswd);

				WebElement day_dropdown = dr.findElement(By.name("phdesktopbody_0$ctl72"));
				System.out.println("Day dropdown field exists -----");
				Select Day = new Select(day_dropdown);
				Day.selectByValue(day);

				WebElement Month_dropdown = dr.findElement(By.name("phdesktopbody_0$ctl74"));
				System.out.println("Month dropdown field exists -----");
				Select Month = new Select(Month_dropdown);
				Month.selectByValue(month);

				WebElement Year_dropdown = dr.findElement(By.name("phdesktopbody_0$ctl76"));
				System.out.println("Year dropdown field exists -----");
				Select Year = new Select(Year_dropdown);
				Year.selectByValue(year);


				WebElement Country_dropdown = dr.findElement(By.id("phdesktopbody_0_labelgrs_account[addresses][0][country]"));
				System.out.println("Country field exists -----");
				Select Country = new Select(Country_dropdown);
				Country.selectByValue(country);

				WebElement Address = dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_labelgrs_account[addresses][0][line1]"));
				System.out.println("Address field exists -----");
				Address.sendKeys(address);

				WebElement Postal = dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_grs_account[addresses][0][postalarea]"));
				System.out.println("Post code field exists -----");
				Postal.sendKeys(postal);

				WebElement City = dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_labelgrs_account[addresses][0][city]"));
				System.out.println("City field exists -----");
				City.sendKeys(city);

				WebElement submit = dr.findElement(By.id("phdesktopbody_0_submit"));
				System.out.println("Submit Button exists -----");
				submit.click();
				
				String url = dr.getCurrentUrl();
				if(url.equals("https://www.olaz.de/de-de/loginpage/create-profile-thank-you-page"))
				{
					System.out.println("Test Passed......");
				}
				else
				{
					System.out.println("Test Failed......");
				}
			} 
			catch (Exception e) 
			{
				System.out.println("Exception is=" +e.getMessage());
			}
		} 
		else if(PageLanguage.equals("España - Español"))
		{
			try 
			{
				System.out.println("Accepting cookie policy once again......");
				WebDriverWait wait = new WebDriverWait(dr, 30);
				wait.until(ExpectedConditions.elementToBeClickable(By.id("onetrust-accept-btn-handler")));
				WebElement cookie = dr.findElement(By.id("onetrust-accept-btn-handler"));
				System.out.println("Cookie button exists......");
				cookie.click();
				
				WebElement gender = dr.findElement(By.id("phdesktopbody_0_imgmale"));
				System.out.println("Gender field exists -----");
				gender.click();

				WebElement Firstname = dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_grs_consumer[firstname]"));
				System.out.println("First Name field exists -----");
				Firstname.sendKeys(firstname);

				WebElement Lastname = dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_grs_consumer[lastname]"));
				System.out.println("Last Name field exists -----");
				Lastname.sendKeys(lastname);
				
				WebElement Email = dr.findElement(By.id("phdesktopbody_0_grs_account[emails][0][address]"));
				System.out.println("Email field exists -----");
				Email.sendKeys(username);

				WebElement Password = dr.findElement(By.id("phdesktopbody_0_grs_account[password][password]"));
				System.out.println("Password field exists -----");
				Password.sendKeys(password);

				WebElement Confirmpasswd = dr.findElement(By.id("phdesktopbody_0_grs_account[password][confirm]"));
				System.out.println("Confirm Password field exists -----");
				Confirmpasswd.sendKeys(confirmpasswd);

				WebElement day_dropdown = dr.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][day]"));
				System.out.println("DayDropDown exists -----");
				Select Day = new Select(day_dropdown);
				Day.selectByValue(day);

				WebElement month_dropdown = dr.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][month]"));
				System.out.println("MonthDropDown exists -----");
				Select Month = new Select(month_dropdown);
				Month.selectByValue(month);

				WebElement year_dropdown = dr.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][year]"));
				System.out.println("YearDropDown exists -----");
				Select Year = new Select(year_dropdown);
				Year.selectByValue(year);

				WebElement telephone = dr.findElement(By.id("phdesktopbody_0_grs_account[phones][0][fulltelephonenumber]"));
				System.out.println("Telephone number exists -----");
				telephone.sendKeys("+34910600484");

				WebElement option1 = dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_ctl74"));
				System.out.println("Toggle field exists -----");
				// This will Toggle the Check box 		
				option1.click();
				WebElement submit = dr.findElement(By.name("phdesktopbody_0$phdesktopbody_0_submit"));
				System.out.println("Submit Button exists -----");
				submit.click();
				
				String url = dr.getCurrentUrl();
				if(url.equals("https://www.olay.es/es-es/loginpage/create-profile-thank-you-page"))
				{
					System.out.println("Test Passed......");
				}
				else
				{
					System.out.println("Test Failed......");
				}	
			} 
			catch (Exception e) 
			{
				System.out.println("Exception is=" +e.getMessage());	
			}
		}

	}
	@DataProvider(name="testData")
	public  Object[][] readExcel() throws IOException
	{
		return DataProviderExcel.readExcel("./src/test/resources/ExcelFile/Reg.xls", "Sheet1");

	}
}