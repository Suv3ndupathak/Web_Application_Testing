package Assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DateOfBirth extends demoqaBaseClass
{
	@Test(dataProvider="testdata")
	public void datepicker(String month, String year) throws InterruptedException 
	{
		try {
			WebElement Date = dr.findElement(By.id("datePickerMonthYearInput"));
			System.out.println("Date field exist......");
			Date.click();
			Select SelectMonth = new Select(dr.findElement(By.className("react-datepicker__month-select")));
			System.out.println("Month dropdown exist......");
			SelectMonth.selectByVisibleText(month);
			Select SelectYear = new Select(dr.findElement(By.className("react-datepicker__year-select")));
			System.out.println("Year dropdown exist......");
			SelectYear.selectByValue(year);
			WebElement selectDate = dr.findElement(By.xpath("//div[text()='6']"));
			System.out.println("Year dropdown exist......");
			selectDate.click();
		} 
		catch (Exception e) 
		{
			System.out.println("Exception is= "+e.getMessage());
		}
	}
	@Test(dataProvider="testdata1")
	public void datepicker2(String date)
	{
		try
		{
			//Check whether datepicker field exists or not 
			WebElement wb=dr.findElement(By.id("dateAndTimePickerInput"));
			System.out.println("Datepicker field exists -----");
			wb.sendKeys(Keys.CONTROL + "a");
			wb.sendKeys(Keys.DELETE);
			wb.sendKeys(date);
			WebElement time=dr.findElement(By.xpath("//li[text()='14:45']"));
			System.out.println("Time exists......");
			time.click();
		}
		catch(Throwable e)
		{
			System.out.println("Exception is= "+e.getMessage());
		}
	}
	@DataProvider(name="testdata")
	public Object[][] TestDataFeed()
	{
		Object [][] data=new Object[1][2];

		data[0][0]="December";
		data[0][1]="1998";
		return data;
	}
	@DataProvider(name="testdata1")
	public Object[][] TestDataFeed1()
	{
		Object [][] data=new Object[1][1];

		data[0][0]="12/06/1998";
		
		return data;
	}

}
