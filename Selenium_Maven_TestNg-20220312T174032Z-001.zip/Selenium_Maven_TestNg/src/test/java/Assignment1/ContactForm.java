package Assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ContactForm extends demoqaBaseClass
{
	@Test(dataProvider="testdata")
	public void Form(String FirstName, String LastName, String Email, 
			String Mobile, String Month, String Year, String file, String Address) 
	{
		try
		{
		
		WebElement firstName=dr.findElement(By.id("firstName"));
		System.out.println("First name field exists......");
		firstName.sendKeys(FirstName);

		WebElement lastName=dr.findElement(By.id("lastName"));
		System.out.println("Last name field exists......");
		lastName.sendKeys(LastName);

		WebElement email=dr.findElement(By.id("userEmail"));
		System.out.println("Email field exists......");
		email.sendKeys(Email);

		WebElement Gender=dr.findElement(By.xpath("//label[text()='Male']"));
		System.out.println("Gender radio button exists......");
		Gender.click();

		WebElement mobile=dr.findElement(By.id("userNumber"));
		System.out.println("Mobile field exists......");
		mobile.sendKeys(Mobile);

		WebElement Date = dr.findElement(By.id("dateOfBirthInput"));
		System.out.println("Date field exist......");
		Date.click();
		
		Select SelectMonth = new Select(dr.findElement(By.className("react-datepicker__month-select")));
		System.out.println("Month dropdown exist......");
		SelectMonth.selectByVisibleText(Month);
		
		Select SelectYear = new Select(dr.findElement(By.className("react-datepicker__year-select")));
		System.out.println("Year dropdown exist......");
		SelectYear.selectByValue(Year);
		
		WebElement selectDate = dr.findElement(By.xpath("//div[text()='6']"));
		System.out.println("Day exist......");
		selectDate.click();
		
		WebElement fileInput = dr.findElement(By.id("uploadPicture"));
		System.out.println("Uploading file......");
		fileInput.sendKeys(file);
		
		WebElement add=dr.findElement(By.id("currentAddress"));
		System.out.println("Address field exist......");
		add.sendKeys(Address);
		
		dr.findElement(By.xpath("//div[text()='Select State']")).click();
		System.out.println("Selecting the State......");
		Actions act = new Actions(dr);
	    act.sendKeys(Keys.DOWN).perform();
	    act.sendKeys(Keys.ENTER).perform();
	    
	    dr.findElement(By.xpath("//div[text()='Select City']")).click();
	    System.out.println("Selecting the city......");
		Actions act1 = new Actions(dr);
	    act1.sendKeys(Keys.DOWN).perform();
	    act1.sendKeys(Keys.ENTER).perform();
	    
	    WebElement Submit=dr.findElement(By.id("submit"));
	    System.out.println("Submitting the form......");
	    Submit.click();
		}
		catch(Exception e)
		{
			System.out.println("Exception is= " +e.getMessage());
		}
		
	}
	@DataProvider(name="testdata")
	public Object[][] TestDataFeed()
	{
		Object [][] data=new Object[1][8];

		data[0][0]="Suvendu";
		data[0][1]="Pathak";
		data[0][2]="ode@@gmail.com";
		data[0][3]="6524872667";
		data[0][4]="November";
		data[0][5]="1995";	
		data[0][6]="/home/suvendu/Pictures/Walpaper/river.jpg";
		data[0][7]="NewYork, USA";	
		return data;
	}

}
