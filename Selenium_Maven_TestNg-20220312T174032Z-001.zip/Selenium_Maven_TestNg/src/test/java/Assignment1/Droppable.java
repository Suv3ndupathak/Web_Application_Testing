package Assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Droppable extends demoqaBaseClass
{
	@Test
	public void Execution()
	{
		try
		{		
			//Check whether From field exists or not 
			WebElement From=dr.findElement(By.id("draggable"));
			System.out.println("From field exists -----");
			//Check whether To field exists or not 
			WebElement To=dr.findElement(By.id("droppable"));
			System.out.println("To field exists -----");	
			Actions act=new Actions(dr);					
			//Dragged and dropped	
			act.dragAndDrop(From, To).build().perform();
		}
		catch(Throwable e)
		{
			System.out.println("ElementNotfound: " + e.getMessage());
		}					
		try
		{
			WebElement msg=dr.findElement(By.xpath("//*[@id=\"droppable\"]/p"));
			String text=msg.getText();
			String expectedText = "Dropped!";
			Assert.assertEquals(text,expectedText);
			System.out.println("The file has been dropped");
		}
		catch(Throwable e)
		{
			System.out.println("ElementNotfound: " + e.getMessage());
		}
	}
}
