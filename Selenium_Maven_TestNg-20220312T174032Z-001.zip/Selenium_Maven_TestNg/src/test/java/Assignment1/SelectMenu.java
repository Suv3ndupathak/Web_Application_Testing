package Assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SelectMenu extends demoqaBaseClass
{
	@Test(dataProvider="testdata")
	public void select(String menuNo)
	{
		try
		{
			WebElement value=dr.findElement(By.className("css-1hwfws3"));
			System.out.println("Value field exists......");
			value.click();
			WebElement choose= dr.findElement(By.xpath("//div[text()='Group 1, option 1']"));
			System.out.println("Value has been selected......");
			choose.click();
			
			WebElement title=dr.findElement(By.xpath("//div[text()='Select Title']"));
			System.out.println("Title field exists......");
			title.click();
			WebElement choose1= dr.findElement(By.xpath("//div[text()='Mr.']"));
			System.out.println("Title has been selected......");
			choose1.click();
			
			Select menu=new Select(dr.findElement(By.id("oldSelectMenu")));
			System.out.println("Dropdown exists......");
			menu.selectByValue(menuNo);
		}
		catch(Exception e)
		{
			System.out.println("The exception is= "+e.getMessage());
		}	
	}
	@DataProvider(name="testdata")
	public Object[][] TestDataFeed()
	{
		Object [][] data=new Object[1][1];

		data[0][0]="3";
		return data;
	}
}
