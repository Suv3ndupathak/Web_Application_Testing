package Assignment1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
public class Selectable extends demoqaBaseClass
{
	@Test
	public void SelectItems() throws InterruptedException
	{
		try
		{
			//Check whether Items are exists or not 
			List<WebElement> Items=dr.findElements(By.id("verticalListContainer"));
			System.out.println("Items are exists -----");
			for(WebElement webElement : Items)
			{
				webElement.click();
				String name=webElement.getText();
				System.out.println(name);
			}
		}
		catch(Throwable e)
		{
			System.out.println("ElementNotFound: " + e.getMessage());
		}

	}
}
