package Assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Menu extends demoqaBaseClass
{
	@Test
	public void menu()
	{
		try
		{
			WebElement mainItem2=dr.findElement(By.xpath("//a[text()='Main Item 2']"));
			System.out.println("Main item exist......");
			System.out.println(mainItem2.getText());
			mainItem2.click();
			WebElement sublist=dr.findElement(By.xpath("//a[text()='SUB SUB LIST »']"));
			System.out.println("Sublist item exist......");
			System.out.println(sublist.getText());
			sublist.click();
			WebElement subItem1=dr.findElement(By.xpath("//a[text()='Sub Sub Item 1']"));
			System.out.println("Subitem item exist......");
			System.out.println(subItem1.getText());
			subItem1.click();
		}
		catch(Throwable e)
		{
			System.out.println("The exception is= " +e.getMessage());
		}
	}
}
